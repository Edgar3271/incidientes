# Proyecto para Respuesta a Incidentes de Seguridad

# REQUISITOS

## Xampp[PHP y Perl] (SOLO INSTALAR Y YA)
<p align="center"><a href="https://www.apachefriends.org/es/download.html" target="_blank"><img src="https://www.apachefriends.org/images/xampp-logo-ac950edf.svg" width="400" alt="XAMPP Logo"></a></p>
XAMPP es una distribución de Apache completamente gratuita y fácil de instalar que contiene MariaDB, PHP y Perl. El paquete de instalación de XAMPP ha sido diseñado para ser increíblemente fácil de instalar y usar.

Nota; primero instalar xampp y despues composer

## Composer
<p align="center"><a href="https://getcomposer.org/download/" target="_blank"><img src="https://upload.wikimedia.org/wikipedia/commons/2/26/Logo-composer-transparent.png" width="400" alt="Composer Logo"></a></p>
Composer no es un administrador de paquetes en el mismo sentido que lo son Yum o Apt. Sí, se ocupa de "paquetes" o bibliotecas, pero los administra por proyecto, instalándolos en un directorio (por ejemplo, vendor) dentro de su proyecto. Por defecto, no instala nada globalmente. Por tanto, es un gestor de dependencia. Sin embargo, admite un proyecto "global" por conveniencia a través del comando global.

### Descargar componentes PHP el siguiente comando y despues presione Enter
    composer require

### Migrar la base de datos
    php artisan migrate

### Insertar seeders
    php artisan db:seed

### Por ultimo correr servidor local
    php artisan serve

## Node.js
<p align="center"><a href="https://nodejs.org/en" target="_blank"><img src="https://nodejs.org/static/images/logo.svg" width="400" alt="Node.js Logo"></a></p>
Node.js® es un entorno de ejecución de JavaScript multiplataforma, de código abierto y gratuito que permite a los desarrolladores crear servidores, aplicaciones web, herramientas de línea de comandos y scripts.

### Instalar componentes Node.js
    npm install

### Correr los modulos de Node.js desarrollador
    npm run dev