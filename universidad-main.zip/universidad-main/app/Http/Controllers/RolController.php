<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class RolController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:menu-roles', ['only' => ['index']]);
        $this->middleware('permission:crear-roles', ['only' => ['create', 'sotre']]);
        $this->middleware('permission:editar-roles', ['only' => ['edit', 'update']]);
        $this->middleware('permission:eliminar-roles', ['only' => ['destroy']]);
    }
    public function index()
    {
        $roles = Role::paginate(5);
        $permission = Permission::get();
        return view('roles.index', compact('roles'), compact('permission'));
    }

    public function create()
    {
        // $permission = Permission::get();
        // return view('roles.create', compact('permission'));
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|unique:roles,name',
            'permission' => 'required',
        ]);

        $role = Role::create(['name' => $request->input('name')]);
        $role->syncPermissions($request->input('permission'));

        return redirect()
            ->route('roles.index')
            ->with('mensaje', 'Rol agregado');
    }

    public function show($role)
    {
        //
    }

    public function edit($id)
    {
        $role = Role::find($id);
        $permission = Permission::get();
        $rolePermissions = DB::table('role_has_permissions')
            ->where('role_has_permissions.role_id', $id)
            ->pluck('role_has_permissions.permission_id', 'role_has_permissions.permission_id')
            ->all();
        return view('roles.edit', [
            'role' => $role,
            'permission' => $permission,
            'rolePermissions' => $rolePermissions,
        ]);
    }

    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'name' => 'required',
            'permission' => 'required',
        ]);
        $role = Role::find($id);
        $role->name = $request->input('name');
        $role->save();
        $role->syncPermissions($request->input('permission'));
        return redirect()
            ->route('roles.index')
            ->with('mensaje', 'Rol actualizado');
    }

    public function destroy($id)
    {
        DB::table('roles')
            ->where('id', $id)
            ->delete();
        return redirect()
            ->route('roles.index')
            ->with('mensaje', 'Rol eliminado');
    }
}
