<?php

namespace App\Http\Controllers;

use App\Models\User;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;

class UsuarioController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:menu-usuarios', ['only' => ['index']]);
        $this->middleware('permission:crear-usuarios', ['only' => ['create', 'sotre']]);
        $this->middleware('permission:editar-usuarios', ['only' => ['edit', 'update']]);
        $this->middleware('permission:eliminar-usuarios', ['only' => ['destroy']]);
    }
    public function index()
    {
        $usuarios = User::paginate(5);
        $roles = Role::pluck('name', 'name')->all();
        return view('usuarios.index', compact('usuarios'), compact('roles'));
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'patern' => 'required',
            'matern' => 'required',
            'email' => 'required|email|unique:users,email',
            'phone' => 'unique:users,phone|min:10|max:10',
            'roles' => 'required',
        ]);
        $input = $request->all();
        $input['password'] = Hash::make($input['password']);
        $user = User::create($input);
        $user->assignRole($request->input('roles'));
        return redirect()->route('usuarios.index')->with('mensaje', 'Usuario agregado');
    }

    public function show(string $usuario)
    {
        //
    }

    public function edit($id)
    {
        $usuario = User::find($id);
        $roles = Role::pluck('name', 'name')->all();
        $userRole = $usuario->roles->pluck('name', 'name')->first();
        return view('usuarios.edit', compact('usuario', 'roles', 'userRole'));
    }

    public function update(Request $request, User $usuario)
    {
        $this->validate($request, [
            'name' => 'required',
            'roles' => 'required',
        ]);
        $input = $request->all();
        if (!empty($input['password'])) {
            $input['password'] = Hash::make($input['password']);
        } else {
            $input = Arr::except($input, ['password']);
        }
        $usuario->update($input);
        DB::table('model_has_roles')
            ->where('model_id', $usuario->id)
            ->delete();
        $usuario->assignRole($request->input('roles'));
        return redirect()->route('usuarios.index')->with('mensaje', 'Usuario actualizado');
    }

    public function destroy(User $usuario)
    {
        $usuario->delete();
        return redirect()->route('usuarios.index')->with('mensaje', 'Usuario eliminado');
    }
}
