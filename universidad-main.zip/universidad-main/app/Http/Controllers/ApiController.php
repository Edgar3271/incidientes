<?php
namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class ApiController extends Controller
{
    public function users(Request $request)
    {
        if ($request->has('active')) {
            $users = User::where('active', true)->get();
        } else {
            $users = User::all();
        }
        return response()->json($users);
    }

    public function login(Request $request)
    {
        $response = ['status' => 0, 'message' => ''];
        $data = json_decode($request->getContent());
        $user = User::where('email', $data->email)->first();
        if ($user) {
            if (Hash::check($data->password, $user->password)) {
                $token = $user->createToken('apiTok');
                $response['status'] = 1;
                $response['token'] = $token->plainTextToken;
            } else {
                $response['message'] = '¡CREDENCIAL ERRONEA!';
            }
        } else {
            $response['message'] = '¡USUARIO NO ENCONTRADO!';
        }
        return response()->json($response);
    }
}
