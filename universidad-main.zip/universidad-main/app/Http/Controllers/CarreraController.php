<?php

namespace App\Http\Controllers;

use App\Models\Carrera;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;

class CarreraController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:menu-carreras', ['only' => ['index']]);
        $this->middleware('permission:crear-carreras', ['only' => ['create', 'sotre']]);
        $this->middleware('permission:editar-carreras', ['only' => ['edit', 'update']]);
        $this->middleware('permission:eliminar-carreras', ['only' => ['destroy']]);
    }
    public function index()
    {
        $carreras = Carrera::paginate(5);
        return view('carreras.index', compact('carreras'));
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
   
        ]);
        $input = $request->all();
        $carrera = Carrera::create($input);
      
        return redirect()->route('carreras.index')->with('mensaje', 'Carrera agregada');
    }

    
    public function edit($id)
    {
        $carrera = Carrera::find($id);
        return view('carreras.edit', compact('carrera'));
    }

    public function update(Request $request, Carrera $carrera)
    {
        $this->validate($request, [
            'name' => 'required',
        ]);
        $input = $request->all();
      
        $carrera->update($input);
       
        return redirect()->route('carreras.index')->with('mensaje', 'Carrera actualizada');
    }

 
    public function destroy(Carrera $carrera)
    {
        $carrera->delete();
        return redirect()->route('carreras.index')->with('mensaje', 'Carrera eliminada');
    }
}
