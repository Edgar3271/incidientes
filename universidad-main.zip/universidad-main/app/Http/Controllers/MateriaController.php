<?php

namespace App\Http\Controllers;

use App\Models\Materia;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;

class MateriaController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:menu-materias', ['only' => ['index']]);
        $this->middleware('permission:crear-materias', ['only' => ['create', 'sotre']]);
        $this->middleware('permission:editar-materias', ['only' => ['edit', 'update']]);
        $this->middleware('permission:eliminar-materias', ['only' => ['destroy']]);
    }
    public function index()
    {
        $materias = Materia::paginate(5);
        return view('materias.index', compact('materias'));
    }


    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
   
        ]);
        $input = $request->all();
        $materias = Materia::create($input);
      
        return redirect()->route('materias.index')->with('mensaje', 'Materia agregada');
    }

 
    public function edit($id)
    {
        $materia = Materia::find($id);
        return view('materias.edit', compact('materia'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Materia $materia)
    {
        $this->validate($request, [
            'name' => 'required',
            'credit' => 'required',
        ]);
        $input = $request->all();
      
        $materia->update($input);
       
        return redirect()->route('materias.index')->with('mensaje', 'Materia actualizada');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Materia $materia)
    {
        $materia->delete();
        return redirect()->route('materias.index')->with('mensaje', 'Materia eliminada');
    }
}
