<?php

namespace App\Http\Controllers;

use App\Models\Dependencia;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;

class DependenciaController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:menu-dependencias', ['only' => ['index']]);
        $this->middleware('permission:crear-dependencias', ['only' => ['create', 'sotre']]);
        $this->middleware('permission:editar-dependencias', ['only' => ['edit', 'update']]);
        $this->middleware('permission:eliminar-dependencias', ['only' => ['destroy']]);
    }
    public function index()
    {
        $dependencias = Dependencia::paginate(5);
        return view('dependencias.index', compact('dependencias'));
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
   
        ]);
        $input = $request->all();
        $dependencia = Dependencia::create($input);
      
        return redirect()->route('dependencias.index')->with('mensaje', 'Dependencia agregada');
    }

    public function edit($id)
    {
        $dependencia = Dependencia::find($id);
        return view('dependencias.edit', compact('dependencia'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Dependencia $dependencia)
    {
        $this->validate($request, [
            'name' => 'required',
        ]);
        $input = $request->all();
      
        $dependencia->update($input);
       
        return redirect()->route('dependencias.index')->with('mensaje', 'Dependencia actualizada');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Dependencia $dependencia)
    {
        $dependencia->delete();
        return redirect()->route('dependencias.index')->with('mensaje', 'Dependencia eliminada');
    }
}
