<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\CategoriaController;
use App\Http\Controllers\ProviderController;
use App\Http\Controllers\ProductoController;
use App\Http\Controllers\CarritoController;
use App\Http\Controllers\ComprasController;
use App\Http\Controllers\VentasController;
use App\Http\Controllers\RolController;
use App\Http\Controllers\UsuarioController;
use App\Http\Controllers\DependenciaController;
use App\Http\Controllers\MateriaController;
use App\Http\Controllers\CarreraController;

Route::get('/', function () {
    return view('index');
});

Route::middleware('auth')->group(function () {
    Route::resource('/usuarios', UsuarioController::class);
    Route::resource('/carreras', CarreraController::class);
    Route::resource('/dependencias', DependenciaController::class);
    Route::resource('/materias', MateriaController::class);
    Route::resource('/roles', RolController::class);
    Route::get('/perfil', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/perfil', [ProfileController::class, 'update'])->name('profile.update');
    // Route::delete('/perfil', [ProfileController::class, 'destroy'])->name('profile.destroy');


});

require __DIR__ . '/auth.php';
