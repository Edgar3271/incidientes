<title>Editar dependencia</title>
<x-app-layout>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class=" text-gray-900 dark:text-gray-100">
                <div
                    class="card p-2 sm:p-8bg-white-gray-800 dark:bg-gray-800 border-b border-gray-300 dark:border-gray-700 shadow sm:rounded-lg">
                    <div class="card-header">
                        <h1>Editar dependencia</h1>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('dependencias.update', $dependencia) }}" method="POST">
                            @csrf @method('PATCH')
                            <div class="row mb-3">
                                <div class="col">
                                    <x-input-label for="name" :value="__('Nombre de Dependenia')" />
                                    <x-text-input id="name" name="name" type="text"
                                        class="mt-1 block w-full  text-gray-900 dark:text-gray-100" :value="old('name', $dependencia->name)"
                                        required autofocus autocomplete="name" />
                                    <x-input-error class="mt-2" :messages="$errors->get('name')" />
                                </div>
                                
                            </div>
                            
                            <div class="col-12 text-end">
                                <button type="submit" class="btn btn-primary">Guardar</button>
                                <a href="{{ route('dependencias.index') }}">
                                    <button type="button" class="btn btn-danger">Cancelar</button>
                                </a>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
