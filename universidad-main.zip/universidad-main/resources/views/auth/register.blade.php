<x-guest-layout>
    <form method="POST" action="{{ route('register') }}">
        @csrf
        <div class="row mt-4">
            <div class="col">
                <x-input-label for="email" :value="__('Correo')" />
                <x-text-input id="email" class="block mt-1 w-full" type="email" name="email" required autofocus
                    autocomplete="off" />
                <x-input-error :messages="$errors->get('email')" class="mt-2" />
            </div>
            <div class="col">
                <x-input-label for="phone" :value="__('Telefóno')" />
                <x-text-input id="phone" name="phone" type="tel" min="0000000000" max="9999999999"
                    maxlength="10" required autofocus class="mt-1 block w-full  text-gray-900 dark:text-gray-100"
                    autocomplete="off" />
                {{-- <x-input-error class="mt-2" :messages="$errors->get('phone')" /> --}}
            </div>
        </div>
        <div class="row mt-4">
            <div class="col">
                <x-input-label for="name" :value="__('Nombre(s)')" />
                <x-text-input id="name" class="block mt-1 w-full" type="text" name="name" required autofocus
                    autocomplete="off" />
                {{-- <x-input-error :messages="$errors->get('name')" class="mt-2" /> --}}
            </div>
            <div class="col">
                <x-input-label for="patern" :value="__('A. Paterno')" />
                <x-text-input id="patern" class="block mt-1 w-full" type="text" name="patern" required autofocus
                    autocomplete="off" />
                {{-- <x-input-error :messages="$errors->get('patern')" class="mt-2" />
            </div> --}}
                <div class="col">
                    <x-input-label for="matern" :value="__('A. Materno')" />
                    <x-text-input id="matern" class="block mt-1 w-full" type="text" name="matern" required
                        autofocus autocomplete="off" />
                    {{-- <x-input-error :messages="$errors->get('matern')" class="mt-2" /> --}}
                </div>
            </div>
            <div class="row mt-4">
                <div class="col">
                    <x-input-label for="password" :value="__('Contraseña')" />
                    <x-text-input id="password" class="block mt-1 w-full" type="password" name="password" required
                        autofocus autocomplete="off" />
                    <x-input-error :messages="$errors->get('password')" class="mt-2" />
                </div>
                <div class="col">
                    <x-input-label for="password_confirmation" :value="__('Confirmar contraseña')" />
                    <x-text-input id="password_confirmation" class="block mt-1 w-full" type="password"
                        name="password_confirmation" required autofocus autocomplete="off" />
                    <x-input-error :messages="$errors->get('password_confirmation')" class="mt-2" />
                </div>
            </div>
            <div class="flex items-center justify-end mt-4">
                <a class="underline text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
                    href="{{ route('login') }}">
                    ¿Ya estas registrado?
                </a>
                <x-primary-button class="ml-4">
                    Registrarse
                </x-primary-button>
            </div>
    </form>
</x-guest-layout>
