<section>
    <header>
        <h2 class="text-lg font-medium text-gray-900 dark:text-gray-100">
            Informacion de Perfíl
        </h2>

        <p class="mt-1 text-sm text-gray-600 dark:text-gray-400">
            Actualice la información del perfil, dirección de correo electrónico y número de telefóno.
        </p>
    </header>

    <form id="send-verification" method="post" action="{{ route('verification.send') }}">
        @csrf
    </form>

    <form method="post" action="{{ route('profile.update') }}" class="mt-6 space-y-6">
        @csrf
        @method('patch')

        <div class="row">
            <div class="col">
                <x-input-label for="name" :value="__('Nombre')" />
                <x-text-input id="name" name="name" type="text"
                    class="mt-1 block w-full  text-gray-900 dark:text-gray-100" :value="old('name', $user->name)" required autofocus
                    autocomplete="name" />
                <x-input-error class="mt-2" :messages="$errors->get('name')" />
            </div>
            <div class="col">
                <x-input-label for="patern" :value="__('Apellido Paterno')" />
                <x-text-input id="patern" name="patern" type="text"
                    class="mt-1 block w-full  text-gray-900 dark:text-gray-100" :value="old('patern', $user->patern)" required autofocus
                    autocomplete="patern" />
                <x-input-error class="mt-2" :messages="$errors->get('patern')" />
            </div>
            <div class="col">
                <x-input-label for="matern" :value="__('Apellido Materno')" />
                <x-text-input id="matern" name="matern" type="text"
                    class="mt-1 block w-full  text-gray-900 dark:text-gray-100" :value="old('matern', $user->matern)" required autofocus
                    autocomplete="matern" />
                <x-input-error class="mt-2" :messages="$errors->get('matern')" />
            </div>
        </div>

        <div class="row">
            <div class="col">
                <x-input-label for="email" :value="__('Correo')" />
                <x-text-input id="email" name="email" type="email"
                    class="mt-1 block w-full  text-gray-900 dark:text-gray-100" :value="old('email', $user->email)" required
                    autocomplete="email" />
                <x-input-error class="mt-2" :messages="$errors->get('email')" />
            </div>
            <div class="col">
                <x-input-label for="phone" :value="__('Telefóno')" />
                <x-text-input id="phone" name="phone" type="tel" min="0000000000" max="9999999999"
                    maxlength="10" class="mt-1 block w-full  text-gray-900 dark:text-gray-100" :value="old('phone', $user->phone)"
                    autocomplete="phone" />
                <x-input-error class="mt-2" :messages="$errors->get('phone')" />
            </div>

            @if ($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && !$user->hasVerifiedEmail())
                <div>
                    <p class="text-sm mt-2 text-gray-800 dark:text-gray-200">
                        Su dirección de correo electrónico no está verificada.

                        <button form="send-verification"
                            class="underline text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800">
                            Haga clic aquí para volver a enviar el correo electrónico de verificación.
                        </button>
                    </p>

                    @if (session('status') === 'verification-link-sent')
                        <p class="mt-2 font-medium text-sm text-green-600 dark:text-green-400">
                            Se ha enviado un nuevo enlace de verificación a su dirección de correo electrónico.
                        </p>
                    @endif
                </div>
            @endif
        </div>

        <div class="flex items-center gap-4">
            <x-primary-button>Guardar</x-primary-button>

            @if (session('status') === 'profile-updated')
                <p x-data="{ show: true }" x-show="show" x-transition x-init="setTimeout(() => show = false, 2000)"
                    class="text-sm text-gray-600 dark:text-gray-400">Guardado.</p>
            @endif
        </div>
    </form>
</section>
