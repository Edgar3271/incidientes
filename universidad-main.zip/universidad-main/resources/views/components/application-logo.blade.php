<div  class="scale-100 p-6 bg-white dark:bg-gradient-to-bl dark:ring-1 dark:ring-inset dark:ring-white/5 rounded-lg shadow-2xl shadow-gray-500/20 dark:shadow-none flex motion-safe:hover:scale-[1.01] transition-all duration-250">
                <img src="{{ asset('Logo.png') }}">
                </div>