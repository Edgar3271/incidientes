<title>Editar rol</title>
<x-app-layout>
    <div class="py-6">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="p-6 text-gray-900 dark:text-gray-100">
                <div
                    class="card p-2 sm:p-8bg-white-gray-800 dark:bg-gray-800 border-b border-gray-300 dark:border-gray-700 shadow sm:rounded-lg">
                    <div class="card-header">
                        <h1>Editar rol</h1>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('roles.update', $role->id) }}" method="POST">
                            @csrf
                            @method('PATCH')
                            <div class="row">
                                <div class="col-12">
                                    <div class="formg-group mb-3">
                                        <x-input-label for="name" :value="__('Nombre del ROL')" />
                                        <x-text-input id="name" required value="{{ old('name', $role->name) }}"
                                            autofocus name="name" type="text"
                                            class="mt-1 block w-full  text-gray-900 dark:text-gray-100"
                                            placeholder="..." />
                                    </div>
                                    <div class="form-group mb-3">
                                        <x-input-label for="permisos" :value="__('Permisos')" />
                                        <select size="8" name="permission[]" multiple="multiple" id=""
                                            class="form-control border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                                            @forelse ($permission as $permiso)
                                                <option value="{{ $permiso->name }}" <?php foreach ($rolePermissions as $rp) {
                                                    if ($rp == $permiso->id) {
                                                        echo 'selected';
                                                    }
                                                } ?>>
                                                    {{ $permiso->name }}</option>
                                            @empty
                                            @endforelse
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-12 text-end">
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                    <a href="{{ route('roles.index') }}">
                                        <button type="button" class="btn btn-danger">Cancelar</button>
                                    </a>
                                </div>
                            </div>
                        </form>
                        {{-- @include('notificacion') --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
