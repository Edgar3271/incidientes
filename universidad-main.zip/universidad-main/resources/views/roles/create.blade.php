<section class="space-y-6">
    <x-primary-button x-data="" x-on:click.prevent="$dispatch('open-modal', 'create-rol')"
        class="text-gray-900 dark:text-white">Agregar</x-primary-button>
    <x-modal name="create-rol" focusable>
        <form action="{{ route('roles.store') }}" method="POST" class="p-6">
            @csrf
            <div class="row">
                <div class="col-12">
                    <div class="formg-group mb-3">
                        <x-input-label for="name" class="text-gray-900 dark:text-gray-100" :value="__('Nombre del ROL')" />
                        <x-text-input id="name" required autofocus name="name" type="text"
                            class="mt-1 block w-full  text-gray-900 dark:text-gray-100" placeholder="..." />
                    </div>
                    <div class="form-group mb-3">
                        <x-input-label for="permisos" class="text-gray-900 dark:text-gray-100" :value="__('Permisos')" />
                        <select size="8" name="permission[]" multiple="multiple" id=""
                            class="form-control  border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                            @forelse ($permission as $permiso)
                                <option value="{{ $permiso->name }}">{{ $permiso->name }}</option>
                            @empty
                            @endforelse
                        </select>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 text-end ">
                    <x-secondary-button class="ml-3" type="submit">
                        Guardar
                    </x-secondary-button>
                    {{-- <x-danger-button x-on:click="$dispatch('close')" class="ml-3">
                        Cancelar
                    </x-danger-button> --}}
                </div>
            </div>
        </form>
    </x-modal>
</section>
