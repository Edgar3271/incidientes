<section class="space-y-6">
    <x-primary-button x-data="" x-on:click.prevent="$dispatch('open-modal', 'create-users')"
        class="text-gray-900 dark:text-white">Agregar</x-primary-button>
    <x-modal name="create-users" focusable>
        <form method="POST" action="{{ route('materias.store') }}" class="p-6">
            @csrf

            <div class="row  mb-3">
                <div class="col">
                    <x-input-label for="name" :value="__('Nombre Materia')" />
                    <x-text-input id="name" class="block mt-1 w-full" type="text" name="name" required
                        autofocus autocomplete="off" />
                    <x-input-error :messages="$errors->get('name')" class="mt-2" />
                </div>
                <div class="col">
                    <x-input-label for="creditos" :value="__('Creditos')" />
                    <x-text-input id="credit" required name="credit" type="number"
                        min="0" max="999999999999"
                        class="mt-1 block w-full  text-gray-900 dark:text-gray-100"
                        autocomplete="off" />
                </div>
            </div>
            <div class="col-12 text-end  mb-3">
                <x-secondary-button class="ml-3" type="submit">
                    Guardar
                </x-secondary-button>
                {{-- <x-danger-button x-on:click="$dispatch('close')" class="ml-3">
                        Cancelar
                    </x-danger-button> --}}
            </div>

        </form>
    </x-modal>
</section>
