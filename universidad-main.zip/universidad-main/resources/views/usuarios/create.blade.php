<section class="space-y-6">
    <x-primary-button x-data="" x-on:click.prevent="$dispatch('open-modal', 'create-users')"
        class="text-gray-900 dark:text-white">Agregar</x-primary-button>
    <x-modal name="create-users" focusable>
        <form method="POST" action="{{ route('usuarios.store') }}" class="p-6">
            @csrf

            <div class="row  mb-3">
                <div class="col">
                    <x-input-label for="name" :value="__('Nombre(s)')" />
                    <x-text-input id="name" class="block mt-1 w-full" type="text" name="name" required
                        autofocus autocomplete="off" />
                    <x-input-error :messages="$errors->get('name')" class="mt-2" />
                </div>
                <div class="col">
                    <x-input-label for="patern" :value="__('A. Paterno')" />
                    <x-text-input id="patern" class="block mt-1 w-full" type="text" name="patern" required
                        autofocus autocomplete="off" />
                    <x-input-error :messages="$errors->get('patern')" class="mt-2" />
                </div>
                <div class="col">
                    <x-input-label for="matern" :value="__('A. Materno')" />
                    <x-text-input id="matern" class="block mt-1 w-full" type="text" name="matern" required
                        autofocus autocomplete="off" />
                    <x-input-error :messages="$errors->get('matern')" class="mt-2" />
                </div>
            </div>

            <div class="row  mb-3">
                <div class="col">
                    <x-input-label for="email" :value="__('Correo')" />
                    <x-text-input id="email" name="email" type="email"
                        class="mt-1 block w-full  text-gray-900 dark:text-gray-100" autocomplete="email" />
                    <x-input-error class="mt-2" :messages="$errors->get('email')" />
                </div>
                <div class="col">
                    <x-input-label for="phone" :value="__('Telefóno')" />
                    <x-text-input id="phone" name="phone" type="tel" min="0000000000" max="9999999999"
                        maxlength="10" class="mt-1 block w-full  text-gray-900 dark:text-gray-100"
                        autocomplete="phone" />
                    <x-input-error class="mt-2" :messages="$errors->get('phone')" />
                </div>
                <div class="col">
                    <x-input-label for="rol" :value="__('Rol')" />
                    <select name="roles" id="roles"
                        class="form-selectborder-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm"
                        required>
                        <option value="">Seleccionar </option>
                        @forelse ($roles as $rol)
                            <option value="{{ $rol }}">{{ $rol }}</option>
                        @empty
                        @endforelse
                    </select>
                </div>
            </div>
            <div class="row mb-3">

                <div class="col">
                    <x-input-label for="password" :value="__('Contraseña')" />
                    <x-text-input id="password" required name="password" type="password"
                        class="mt-1 block w-full  text-gray-900 dark:text-gray-100" placeholder="*******"
                        autocomplete="off" />
                </div>


            </div>
            <div class="col-12 text-end  mb-3">
                <x-secondary-button class="ml-3" type="submit">
                    Guardar
                </x-secondary-button>
                {{-- <x-danger-button x-on:click="$dispatch('close')" class="ml-3">
                        Cancelar
                    </x-danger-button> --}}
            </div>

        </form>
    </x-modal>
</section>
