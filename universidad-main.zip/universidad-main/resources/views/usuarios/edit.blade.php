<title>Editar usuario</title>
<x-app-layout>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class=" text-gray-900 dark:text-gray-100">
                <div
                    class="card p-2 sm:p-8bg-white-gray-800 dark:bg-gray-800 border-b border-gray-300 dark:border-gray-700 shadow sm:rounded-lg">
                    <div class="card-header">
                        <h1>Editar usuario</h1>
                    </div>
                    <div class="card-body">
                        <form action="{{ route('usuarios.update', $usuario) }}" method="POST">
                            @csrf @method('PATCH')
                            <div class="row mb-3">
                                <div class="col">
                                    <x-input-label for="name" :value="__('Nombre')" />
                                    <x-text-input id="name" name="name" type="text"
                                        class="mt-1 block w-full  text-gray-900 dark:text-gray-100" :value="old('name', $usuario->name)"
                                        required autofocus autocomplete="name" />
                                    <x-input-error class="mt-2" :messages="$errors->get('name')" />
                                </div>
                                <div class="col">
                                    <x-input-label for="patern" :value="__('Apellido Paterno')" />
                                    <x-text-input id="patern" name="patern" type="text"
                                        class="mt-1 block w-full  text-gray-900 dark:text-gray-100" :value="old('patern', $usuario->patern)"
                                        required autofocus autocomplete="patern" />
                                    <x-input-error class="mt-2" :messages="$errors->get('patern')" />
                                </div>
                                <div class="col">
                                    <x-input-label for="matern" :value="__('Apellido Materno')" />
                                    <x-text-input id="matern" name="matern" type="text"
                                        class="mt-1 block w-full  text-gray-900 dark:text-gray-100" :value="old('matern', $usuario->matern)"
                                        required autofocus autocomplete="matern" />
                                    <x-input-error class="mt-2" :messages="$errors->get('matern')" />
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col">
                                    <x-input-label for="email" :value="__('Correo')" />
                                    <x-text-input id="email" name="email" type="email"
                                        class="mt-1 block w-full  text-gray-900 dark:text-gray-100" :value="old('email', $usuario->email)"
                                        required autocomplete="email" />
                                    <x-input-error class="mt-2" :messages="$errors->get('email')" />
                                </div>
                                <div class="col">
                                    <x-input-label for="phone" :value="__('Telefóno')" />
                                    <x-text-input id="phone" name="phone" type="tel" min="0000000000"
                                        max="9999999999" maxlength="10"
                                        class="mt-1 block w-full  text-gray-900 dark:text-gray-100" :value="old('phone', $usuario->phone)"
                                        autocomplete="phone" />
                                    <x-input-error class="mt-2" :messages="$errors->get('phone')" />
                                </div>
                                <div class="col">
                                    <label for="" class="form-label">Rol</label><br>
                                    <select name="roles" id="roles"
                                        class="border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm"
                                        required>
                                        <option value="">Seleccionar </option>
                                        @forelse ($roles as $rol)
                                            <option value="{{ $rol }}" value="{{ $rol }}"
                                                {{ $userRole == $rol ? 'selected' : '' }}>{{ $rol }}
                                            </option>
                                        @empty
                                        @endforelse
                                    </select>
                                </div>
                            </div>
                            <div class="row mb-3">
                                <div class="col">
                                    <x-input-label for="password" :value="__('Contraseña')" />
                                    <x-text-input id="password" class="block mt-1 w-full" type="password"
                                        name="password" required autofocus autocomplete="off" />
                                    <x-input-error :messages="$errors->get('password')" class="mt-2" />
                                </div>
                                <div class="col">
                                    <x-input-label for="password_confirmation" :value="__('Confirmar contraseña')" />
                                    <x-text-input id="password_confirmation" class="block mt-1 w-full" type="password"
                                        name="password_confirmation" required autofocus autocomplete="off" />
                                    <x-input-error :messages="$errors->get('password_confirmation')" class="mt-2" />
                                </div>
                            </div>
                            <div class="col-12 text-end">
                                <button type="submit" class="btn btn-primary">Guardar</button>
                                <a href="{{ route('usuarios.index') }}">
                                    <button type="button" class="btn btn-danger">Cancelar</button>
                                </a>
                            </div>
                            {{-- <div class="row">
                                <div class="col-6">
                                    <div class="form-group mb-3">
                                        <x-input-label for="name" :value="__('Nombre')" />
                                        <x-text-input id="name" required value="{{ old('name', $usuario->name) }}"
                                            name="name" type="text"
                                            class="mt-1 block w-full  text-gray-900 dark:text-gray-100"
                                            placeholder="Fulanito de tal..." autocomplete="off" />
                                    </div>
                                    <div class="form-group mb-3">
                                        <x-input-label for="email" :value="__('Correo')" />
                                        <x-text-input id="email" required
                                            value="{{ old('email', $usuario->email) }}" name="email" type="text"
                                            class="mt-1 block w-full  text-gray-900 dark:text-gray-100"
                                            placeholder="ejemplo@correo.com" autocomplete="off" />
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="form-group mb-3">
                                        <x-input-label for="password" :value="__('Contraseña')" />
                                        <x-text-input id="password" name="password" type="password"
                                            class="mt-1 block w-full  text-gray-900 dark:text-gray-100"
                                            placeholder="*******" autocomplete="off" />
                                    </div>
                                    <div class="form-group mb-3">
                                        <label for="" class="form-label">Rol</label><br>
                                        <select name="roles" id="roles"
                                            class="border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm"
                                            required>
                                            <option value="">Seleccionar </option>
                                            @forelse ($roles as $rol)
                                                <option value="{{ $rol }}" value="{{ $rol }}"
                                                    {{ $userRole == $rol ? 'selected' : '' }}>{{ $rol }}
                                                </option>
                                            @empty
                                            @endforelse
                                        </select>
                                    </div>
                                </div>
                                <div class="col-12 text-end">
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                    <a href="{{ route('usuarios.index') }}">
                                        <button type="button" class="btn btn-danger">Cancelar</button>
                                    </a>
                                </div>
                            </div> --}}
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
