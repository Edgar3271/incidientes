<title>Carreras</title>
<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Carreras') }}
        </h2>
    </x-slot>
    <div class="py-6">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            @include('notificacion')
            <div class=" text-gray-900 dark:text-gray-100">
                <div
                    class="card p-2 sm:p-8bg-white-gray-800 dark:bg-gray-800 border-b border-gray-300 dark:border-gray-700 shadow sm:rounded-lg">
                    <div class="card-header">
                        @can('crear-carreras')
                            @include('carreras.create')
                        @endcan
                       
                    </div>
                    <div class="card-body">

                        <table class="table table-hover text-nowrap table-dark table-responsive p-0">
                            <thead>
                                <tr>
                                    <th>NOMBRE</th>
                       
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($carreras as $carrera)
                                    <tr>
                                        <td class=" text-gray-900 dark:text-gray-100"> {{ $carrera->name }}</td>
                                        
                                        <td>
                                           
                                                @can('editar-carreras')
                                                    <a href="{{ route('carreras.edit', [$carrera]) }}">
                                                        <button class="btn btn-primary">
                                                            <i class="bi bi-pen-fill"></i>
                                                        </button>
                                                    </a>
                                                @endcan
                                                @can('eliminar-carreras')
                                                    <form action="{{ route('carreras.destroy', [$carrera]) }}"
                                                        class="d-inline" method="post">
                                                        @method('delete')
                                                        @csrf
                                                        <button class="btn btn-danger d-inline">
                                                            <i class="bi bi-trash-fill"></i>
                                                        </button>
                                                    </form>
                                                @endcan
                                            
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>

                    </div>
                    <div class="row  p-2">
                        <div class="col ">
                            {{ $carreras->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
