<section class="space-y-6">
    <x-primary-button x-data="" x-on:click.prevent="$dispatch('open-modal', 'create-carrera')"
        class="text-gray-900 dark:text-white">Agregar</x-primary-button>
    <x-modal name="create-carrera" focusable>
        <form method="POST" action="{{ route('carreras.store') }}" class="p-6">
            @csrf

            <div class="row  mb-3">
                <div class="col">
                    <x-input-label for="name" :value="__('Nombre de la Carrera')" />
                    <x-text-input id="name" class="block mt-1 w-full" type="text" name="name" required
                        autofocus autocomplete="off" />
                    <x-input-error :messages="$errors->get('name')" class="mt-2" />
                </div>
        
            </div>
            <div class="col-12 text-end  mb-3">
                <x-secondary-button class="ml-3" type="submit">
                    Guardar
                </x-secondary-button>
                {{-- <x-danger-button x-on:click="$dispatch('close')" class="ml-3">
                        Cancelar
                    </x-danger-button> --}}
            </div>

        </form>
    </x-modal>
</section>
