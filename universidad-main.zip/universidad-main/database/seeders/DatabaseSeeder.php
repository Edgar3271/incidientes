<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use App\Models\User;
use App\Models\Dependencia;
use App\Models\Carrera;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([PermisosSeeder::class]);

        $user = User::create([
            'name' => 'Miguel Angel',
            'patern' => 'Pérez',
            'matern' => 'Díaz',
            'email' => 'miguel.perez25@unach.mx',
            'phone' => '9612445094',
            'password' => Hash::make('respuestitaaincidentitos'),
        ]);
        $role = Role::create([
            'name' => 'Administrador',
        ]);
        $permisos = Permission::pluck('id', 'id')->all();
        $role->syncPermissions($permisos);
        $user->assignRole([$role->id]);


        
        $role = Role::create([
            'name' => 'Inge Desarrollador de Software',
        ]);
        $permisos = Permission::pluck('id', 'id')->all();
        $role->syncPermissions($permisos);
        
        $user = User::create([  
            'name' => 'Edga Alejandro',
            'patern' => 'Velazquez',
            'matern' => 'Martinez',
            'email' => 'edgar.velazquez01@unach.mx',
            'phone' => '9631449009',
            'password' => Hash::make('123456789'),
        ]);
        $user->assignRole([$role->id]);

        $user = User::create([
            'name' => 'Gabriela',
            'patern' => 'Juarez',
            'matern' => 'Trujilo',
            'email' => 'gabriela.juarez10@unach.mx',
            'phone' => '9612301320',
            'password' => Hash::make('123456789'),
        ]);
        $user->assignRole([$role->id]);

        $user = User::create([
            'name' => 'José Manuel',
            'patern' => 'Lopez',
            'matern' => 'Sanchez',
            'email' => 'jose.lopez06@unach.mx',
            'phone' => '9682394832',
            'password' => Hash::make('123456789'),
        ]);
        $user->assignRole([$role->id]);

        $user = User::create([
            'name' => 'José Eduardo',
            'patern' => 'Zarate',
            'matern' => 'Avalos',
            'email' => 'jose.zarate45@unach.mx',
            'phone' => '9612726759',
            'password' => Hash::make('123456789'),
        ]);
        $user->assignRole([$role->id]);


        $rol = Role::create([
            'name' => 'Docente'
        ]);
        $user = User::create([
            'name' => 'Obeth',
            'patern' => 'Regalado',
            'matern' => 'Moreno',
            'email' => 'obeth.regalado@unach.mx',
            'password' => Hash::make('123456789'),
        ]);
        $user->assignRole([$rol->id]);


        $rol = Role::create([
            'name' => 'Alumno'
        ]);

        $dependencia = Dependencia::create(['name'=>'Secretaría para la Inclusión Social y Diversidad Cultural']);
        $dependencia = Dependencia::create(['name'=>'Secretaría Administrativa']);
        $dependencia = Dependencia::create(['name'=>'Secretaría Académica']);
        $dependencia = Dependencia::create(['name'=>'Secretaría General']);
        $carrera = Carrera::create(['name'=>'Ingeniería en Desarrollo y Tecnologías de Software']);
        $carrera = Carrera::create(['name'=>'Licenciatura en Sistemas Computacionales']);
        $carrera = Carrera::create(['name'=>'Licenciatura en Gestión Turística']);
        $carrera = Carrera::create(['name'=>'Licenciatura en Contaduría']);
        $carrera = Carrera::create(['name'=>'Licenciatura en Comercio Internacional']);
        $carrera = Carrera::create(['name'=>'Licenciatura en Agronegocios']);
        $carrera = Carrera::create(['name'=>'Licenciatura en Administración']);
        $carrera = Carrera::create(['name'=>'Licenciatura en Químico Farmacobiólogo']); 
        

        
    }
}
