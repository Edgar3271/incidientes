<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class PermisosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $permisos = [
          'menu-roles',
          'crear-roles',
          'editar-roles',
          'eliminar-roles',

          'menu-usuarios',
          'crear-usuarios',
          'editar-usuarios',
          'eliminar-usuarios',

          'menu-carreras',
          'crear-carreras',
          'editar-carreras',
          'eliminar-carreras',

          'menu-dependencias',
          'crear-dependencias',
          'editar-dependencias',
          'eliminar-dependencias',

          'menu-materias',
          'crear-materias',
          'editar-materias',
          'eliminar-materias'];

        foreach ($permisos as $permiso) {
            Permission::create([
                'name' => $permiso,
                'guard_name' => 'web',
            ]);
        }
    }
}
